<?php $__env->startSection('content'); ?>
<div class="col-lg-12 text-start">
   <form action="/create/todo" method="post">
   <?php echo e(csrf_field()); ?>

   <input type="text" class="form-control input-lg" name="todo" placeholder="Create a new todo">
   </form>
    </div>
</div>
<hr>
<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <?php echo e($todo -> todo); ?> 
    <div class="text-center fs-6">
    <a href="<?php echo e(route('todo.delete',['id' => $todo->id])); ?>" class="btn btn-danger btn-xs">x</a>
    <a href="<?php echo e(route('todo.update',['id' => $todo->id])); ?>" class="btn btn-info btn-xs">Edit</i> </a>
    <?php if(!$todo->completed): ?>
        <a href="<?php echo e(route('todos.completed', ['id' => $todo->id])); ?>" class="btn btn-xs btn-success">Check</i></a>
    <?php else: ?> 
        <span class="text-success">Done</span>
    <?php endif; ?>
    </div>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>