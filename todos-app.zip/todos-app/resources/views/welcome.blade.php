@extends('layout')

@section('content')
    <a href="/todos">Visit my todos</a>

@stop 
