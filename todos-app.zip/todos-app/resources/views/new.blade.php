@extends('layout')

@section('content')
    New page for us.

    @stop
    