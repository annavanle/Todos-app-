
@extends('layout')

@section('content')
<div class="col-lg-12 text-start">
   <form action="/create/todo" method="post">
   {{ csrf_field() }}
   <input type="text" class="form-control input-lg" name="todo" placeholder="Create a new todo">
   </form>
    </div>
</div>
<hr>
@foreach($todos as $todo)
    {{$todo -> todo}} 
    <div class="text-center fs-6">
    <a href="{{route('todo.delete',['id' => $todo->id]) }}" class="btn btn-danger btn-xs">x</a>
    <a href="{{route('todo.update',['id' => $todo->id]) }}" class="btn btn-info btn-xs">Edit</i> </a>
    @if(!$todo->completed)
        <a href="{{route('todos.completed', ['id' => $todo->id]) }}" class="btn btn-xs btn-success">Check</i></a>
    @else 
        <span class="text-success">Done</span>
    @endif
    </div>
    <hr>
@endforeach

@stop 
